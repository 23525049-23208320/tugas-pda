"""
    Praktikum 3
    IF5100 Programming for Data Analytics
    1. Simple OOP
    1g. Polymorphism Flower Class

    Nama    : Muhammad Fahmi Rizal
    NIM     : 23525049
"""

from child_plant import Flower

bunga_mawar = Flower(2022, "Rose Flower", "Mawar", "Mr. Kaeya")

print(bunga_mawar.cetak())
