"""
    Praktikum 3
    IF5100 Programming for Data Analytics
    1. Simple OOP
    1b. Book Class

    Nama    : Muhammad Fahmi Rizal
    NIM     : 23525049
"""

class Book(object):
    pass
    
book = Book()

print("Book :",book)