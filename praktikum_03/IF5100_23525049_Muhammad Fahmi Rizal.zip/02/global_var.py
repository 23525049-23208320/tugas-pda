# max borrow books
MAX_BORROW_BOOK = 2